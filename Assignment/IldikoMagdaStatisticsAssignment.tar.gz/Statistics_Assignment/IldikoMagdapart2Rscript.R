seconddata <- read.table("part_2_student_1062.tdf", header = T)

#exploratory analysis to understand the distribution of the data
str(seconddata)
plot(seconddata)


hist(seconddata$expression_fold)
hist(seconddata$distance)

boxplot(seconddata$expression_fold)
boxplot(seconddata$distance)

library("e1071")


par(mfrow = c(1,2))
plot(density(seconddata$expression_fold), main = "density plot: expression fold", ylab = "Frequency", sub = paste("skewed:", round(e1071::skewness(seconddata$expression_fold), 2)))
polygon(density(seconddata$expression_fold), col = "purple")

plot(density(seconddata$distance), main = "density plot: distance", ylab = "frequency", sub = paste("skewed", round(e1071::skewness(seconddata$distance), 2)))
polygon(density(seconddata$distance), col = "red")


#relationship between the two variables 

cor.test(seconddata$expression_fold, seconddata$distance)
par(mfrow = c(1,1))
plot(seconddata$distance, seconddata$expression_fold)

###--->negative correlation between the two variables

#model and the results of the model

linearmodel <- lm(seconddata$distance~seconddata$expression_fold)
linearmodel
anova(linearmodel)
mymodelsummary <- summary(linearmodel)
mymodelsummary
##'
##'F-stat: 167
##'R -squared: 0.85
##'p-value (for model): 2.536e-13
##'

plot(linearmodel)


#check for:

###should be evenly distributed 
###clustered around low y number 
###no clear paterns

#linearmodel slightly wrong on heterscedaticity
#standardized residuals show slight bell shape


#checking assumptions

meanofresiduals <- mean(mymodelsummary$residuals)
meanofresiduals
### needs to be zero(ish)

# residuals normality

residualsMymodel <- mymodelsummary$residuals
shapiro.test(residualsMymodel)
#high p-value-- null hypothesis(data normally distributed) is not rejected.

install.packages("gvlma")
library("gvlma")

gvlma <- gvlma(linearmodel)
plot.gvlma(gvlma)
gvlma
###---> all assumptions acceptable (in this test)

par(mfrow = c(2,2))
plot(linearmodel)
#visual helps 
hist(mymodelsummary$residuals)

# more numerical help on the normality of residuals 

install.packages("lmtest")
library("lmtest")
lmtest::bptest(linearmodel)
#0.6 p-value  :( (testing the hyptohesis that the variance is constant in residuals)


# Try data transformations to achieve better results
#convert variable(s)
#box-cox transformation 
#append to data 

install.packages("caret")
library("scales")
rescaledData <- rescale(seconddata$expression_fold, to = c(10,15))
rescaledData
changedvariable <-  caret::BoxCoxTrans(rescaledData)
changedvariable
#### rescaled data to above 0 to be able to be able to do box cox transformation 

# append changedvariable to data

seconddata <- cbind(seconddata, transformedExpressionFold = predict(changedvariable, seconddata$expression_fold))
head(seconddata)

#try second linear model for better residuals 

secondmodel <- lm(seconddata$distance ~seconddata$transformedExpressionFold)
summary(secondmodel)
# worse result but still significant results 
par(mfrow = c(1,1))

plot(secondmodel)

## lot worse residuals plot

lmtest::bptest(secondmodel)
gvlma::gvlma(secondmodel)
## still accepted assumptions

#no realistic improvement on residuals 
### try simpler data transformation 

datatransformations <- log(rescaledData)
datatransformations
hist(datatransformations)
#not ideal

thirdmodel <- lm(seconddata$distance~ datatransformations)
thirdmodel
summary(thirdmodel)
# similar success of second model (R - squared lower, still significant )
#intercept also significant 
#maybe two groups or nonlinear relationship created because of the log transformation 

plot(thirdmodel)
# not much visual improvement on residuals 
## worse  qq olot

gvlma::gvlma(thirdmodel)

#assumptions still acceptable 
lmtest::bptest(thirdmodel)
#even higher P-value 


## try transforming both variable 
expressionLog <- log(seconddata$expression_fold + 10) # added plus 10 to both to avoid NANS
expressionLog
hist(expressionLog)
distanceLog <- log(seconddata$distance + 10 )
distanceLog
hist(distanceLog)

plot(expressionLog, distanceLog)

model4 <- lm( distanceLog~ expressionLog)
model4
summary(model4)
anova(model4)
plot(model4)

#better standardized residuals but worse qq plot and residuals-fitted

gvlma::gvlma(model4)

# link function not satisfied -- different type of regression? 
lmtest::bptest(model4)

hist(model4$residuals)
# statistically significant and assumptions acceptable 
# better heteroscedasticity 
#lower F-statistics

##transformation square variable(s)

squareexpression <- seconddata$expression_fold^2
squareexpression
squaredistance <- seconddata$distance^2
plot(squareexpression)
model5 <- lm(squaredistance ~ squareexpression)
model5

summary(model5)
#0.56 R-squared, lower F-statistics, significant
plot(model5)
# standardized residuals not well-behaving
gvlma::gvlma(model5)
plot(model5$residuals)
shapiro.test(model5$residuals)
## residuals may not be  normally distributed 

#visual assessment of models
### visualise data representing the found correlation MODEL4 

plot(distanceLog, expressionLog, pch = 21, cex = 1.3,
     col = "blue", main = "Correlation between luciferase homology and expression in the Brassicaceae plant family ",
     xlab = "pairwise genetic distance (average number of amino acid substituition)",
     ylab = "gene expression fold")

abline(model4 <- lm(expressionLog ~ distanceLog))

### visualise data representing the found correlation LINEARMODEL

plot(seconddata$distance, seconddata$expression_fold, pch = 21, cex = 1.3,
     col = "blue", main = "Correlation between luciferase homology and expression 
     in the Brassicaceae plant family ",
     xlab = "pairwise genetic distance (average number of amino acid substituition)",
     ylab = "gene expression fold")

abline(linearmodel <- lm(seconddata$distance~seconddata$expression_fold ))

### visualise data representing the found correlation THIRDMODEL

plot(seconddata$distance, datatransformations, pch = 21, cex = 1.3,
     col = "blue", main = "Correlation between luciferase homology and expression in the Brassicaceae plant family ",
     xlab = "pairwise genetic distance (average number of amino acid substituition)",
     ylab = "gene expression fold")

abline(thirdmodel <- lm(seconddata$distance~ datatransformations))
## are these true continous variables? 
##transforming the data this way really created two potential groups


### visualise data representing the found correlation MODEL5

plot(squaredistance, squareexpression, pch = 21, cex = 1.3,
     col = "blue", main = "Correlation between luciferase homology and expression in the Brassicaceae plant family ",
     xlab = "pairwise genetic distance (average number of amino acid substituition)",
     ylab = "gene expression fold")

abline(model5 <- lm(squareexpression ~ squaredistance))

