firstdata <- read.table("part_1_student_1062.tdf", header = T)
#exploratory data analysis for normality and variance
str(firstdata)
plot(firstdata)
plot(firstdata$UniFracInd)
hist(firstdata$UniFracInd)
install.packages("e1071")
library("e1071")


#in case later needed 

season <- as.numeric(firstdata$season)
latitude <- as.numeric(firstdata$latitude)


#statistical model chosen 


model1 <- lm(firstdata$UniFracInd ~ firstdata$latitude *firstdata$season)
anova(model1)
model1



# check against assumptions and interpretations
summary1 <- summary(model1)
summary1
model1
shapiro.test(summary1$residuals)
plot(summary1$residuals)
plot(model1)



drop1(model1, test = "F")

#no interaction between latitude and season 

model2 <- lm(firstdata$UniFracInd ~ firstdata$latitude + firstdata$season)

summary2 <- summary(model2)
summary2
plot(model2)


drop1(model2, test = "F")

#better F-statistics value, but R-squared are just not suggesting a good fit



model3 <- lm(firstdata$UniFracInd ~firstdata$season)
summary3 <- summary(model3)
summary3
plot(model3)


##t.test to check for significant difference between the means of groups one by one instead of linear model
## should really result the same 

t.test(firstdata$UniFracInd ~firstdata$season) #means not equal to 0, no statistical significance
t.test(firstdata$UniFracInd ~ firstdata$latitude) #means not equal to 0, no statistical significance


#std difference between aug and jan 

januaryonly <- firstdata$UniFracInd[c(1:10,21:30)]
januaryonly

sd(januaryonly)

August <- firstdata$UniFracInd[c(11:20, 31:40)]
August

sd(August)


# deeper understanding where the variances might come from the data

tuk <- TukeyHSD(model1 <- aov(firstdata$UniFracInd ~ firstdata$latitude *firstdata$season),conf.level = 0.95)


tuk
plot(tuk)
##none of the variances are statistically significant with adjusted p-values to multiple comparison



# see whether variance is significant between January temperate and august tropical measurements only 


JanTemp <- firstdata$UniFracInd[c(21:30)]
JanTemp

AugTrop <- firstdata$UniFracInd[c(11:20)]
AugTrop


t.test(JanTemp, AugTrop)

### no. 
#is there a correlation between how diversity change with season and latitude
install.packages("stargazer")
library(stargazer)

stargazer(model2, model1, column.labels  = c("Main effects", "Interactions"), type = "text", intercept.bottom = F, single.row = F, header = F)


interaction.plot(firstdata$season, firstdata$latitude,
                 firstdata$UniFracInd,
                 ylab = "Mean of UniFrac", 
                 xlab = "Season", 
                 col = c("red", "blue"),
                 main = " Co- variation of microbial diversity with season")



##visualisation of statistics


boxplot(firstdata$UniFracInd ~ firstdata$latitude, main = "Diversity change in latitude" , ylab = "unifrac ", xlab = "Latitude")
boxplot(firstdata$UniFracInd ~ firstdata$season, main = "Diversity change with season", ylab =  "unifrac", xlab = "season")


boxplot(firstdata$UniFracInd ~ firstdata$season + firstdata$latitude,
        main = " Variation in relative Microbial diversity with season and latitude",
        ylab = "UniFraC (relative to reference sample)",
        xlab = "Measured season and latitude",
        las = 1, 
        names = c("Aug.Temp", "Jan.Temp", "Aug.Trop", "Jan.Trop"),
        col = c("red" , "blue", "brown", "orange"))


## further data analysis with distance simulation? 
##clustering and distance analysis? to see any grouping that may not be obvious from statistical tests


distance <- dist(scale(firstdata$UniFracInd), method = "euclidian")
Cluster <- hclust(distance, method = "ward.D2")
plot(Cluster, hang = -1, cex  = 1)

install.packages("dendextend")
library("dendextend")

dendogram <- as.dendrogram(Cluster)


### data originally was ordered according to groups of factors, so the order of 
### numbers  on the dendogram suggest no grouping accoring to the factors. not taken further

