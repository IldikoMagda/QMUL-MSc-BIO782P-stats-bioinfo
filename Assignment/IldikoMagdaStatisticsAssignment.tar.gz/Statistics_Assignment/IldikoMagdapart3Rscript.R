thirddata <- read.table("part_3_student_1062.tdf", header = T)


#exploratory data analysis 


str(thirddata)
plot(thirddata)
#generally looking at the data 
boxplot(thirddata)
hist(thirddata$score_shannon)
hist(thirddata$score_distance)
hist(thirddata$VLoad)

#checking for obvious relationships coming possible from the variables 
plot(thirddata$score_shannon, thirddata$score_distance,
     col = as.numeric(thirddata$tissue))


plot(thirddata$score_shannon, thirddata$score_distance, 
     col = as.numeric(thirddata$CD4))
# add weeks as number variables to check variable relationship with time
thirddata$weeknr[1:40] <- c(1:40)

plot(thirddata$weeknr, thirddata$VLoad,
     col = as.numeric(thirddata$tissue))

plot(thirddata$weeknr, thirddata$VLoad, 
     col = as.numeric(thirddata$CD4))

boxplot(thirddata$tissue, thirddata$VLoad)

#visualising the effect of time on viral load 
cor.test(thirddata$VLoad, thirddata$weeknr)

weekmodel <- lm(thirddata$VLoad ~ thirddata$weeknr)
summary(weekmodel)
abline(weekmodel)
plot(weekmodel)


## simple difference in means of viral load
t.test(thirddata$VLoad[1:20], thirddata$VLoad[21:40]) #by tissue 
# significant difference in viral load according to tissue type




### different approaches to select model that fits the data. first intuition based then automated
mymodel1 <- glm(thirddata$VLoad ~ thirddata$tissue * thirddata$score_shannon)
mymodel1
anova(mymodel1)
summary(mymodel1)
#AIC: 169.54
plot(mymodel1)
drop1(mymodel1, test = "F")
# interaction not necessary




mymodel2 <- glm(thirddata$VLoad ~ thirddata$score_shannon + thirddata$tissue)
anova(mymodel2)
summary(mymodel2)
#AIC: 167.55


mymodel3 <- glm(thirddata$VLoad ~ thirddata$score_shannon + thirddata$score_distance + thirddata$tissue)
anova(mymodel3)
summary(mymodel3)
#AIC: 169.23
#tissue seem to significantly affect viral load 


mymodel4 <- glm(thirddata$VLoad ~ thirddata$tissue)
anova(mymodel4)

summary(mymodel4)
#AIC: 165.55 


plot(mymodel4)
#not nice residuals 

#stepwise approach without interaction

stepwisemodel <- step(lm(thirddata$VLoad ~ thirddata$tissue + thirddata$score_shannon + thirddata$score_distance + thirddata$CD4), direction = "both")
##as a result of this the next model  tried next-->


stepwisemodelbest <- lm(thirddata$VLoad ~thirddata$tissue )
anova(stepwisemodelbest)
summary(stepwisemodelbest)

##Viral load change can be described by the tissue type

boxplot((thirddata$VLoad ~ thirddata$tissue), ylab = "Viral Population size (log10 viral particles per ml)", main = "Viral load change according to tissue type")




#correlation test between viral load and diversity 


corrTest <- cor.test(thirddata$VLoad, thirddata$score_shannon)
corrTest
#not statistically significant correlation with with viral load and diversity

#viral load a cd4 count in general circulation 
CD4 <- as.numeric(thirddata$CD4)
CD4
boxplot(thirddata$VLoad, CD4,
        main = "Viral load change across high or low levels of CD4
        general circulation", 
        xlab = "CD4 Levels: high (left) and low ", 
        ylab = "viral load (log10 number of viral particles ml)",
        col = c("red","blue"))
highCD4 <- thirddata$VLoad[c(1:10,21:30)]
highCD4
lowCD4 <- thirddata$VLoad[c(11:20, 31:40)]
lowCD4
t.test(highCD4, lowCD4)
# not significant 

## find a model that descibes better the variance 
modelnotissue <- step(glm(thirddata$VLoad ~ thirddata$CD4 + thirddata$score_shannon +thirddata$score_distance), direction = "both")


model4 <- glm(thirddata$VLoad ~ thirddata$score_shannon)
anova(model4)
summary(model4)
#AIC 171.61


